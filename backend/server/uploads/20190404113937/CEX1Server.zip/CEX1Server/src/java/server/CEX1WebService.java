/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import java.util.ArrayList;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author Gab
 */
@WebService(serviceName = "CEX1WebService")
public class CEX1WebService {
    /*
     ArrayList of all Strings
     */

    ArrayList<String> allStrings = new ArrayList<String>();
    /*
     ArrayList of all Strings
     */
    ArrayList<Student> allStudents = new ArrayList<Student>();

    /**
     * Web service operation
     */
    @WebMethod(operationName = "testConnection")
    public Boolean testConnection() {
        System.out.println("[SERVER] - Testing Connection");
        return true;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "calculateSumBetween")
    public Double calculateSumBetween(@WebParam(name = "a") Double a, @WebParam(name = "b") Double b) {
        System.out.println("[SERVER] - calculateSumBetween");
        return (a + b);
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "calculateSumBetweenWithException")
    public Double calculateSumBetweenWithException(@WebParam(name = "a") Double a, @WebParam(name = "b") Double b) throws Exception {
        System.out.println("[SERVER] - calculateSumBetweenWithExceptionWithException");

        if (a == null) {
            throw new Exception();
        }

        if (b == null) {
            throw new Exception();
        }

        return (a + b);

    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "addString")
    public String addString(@WebParam(name = "str") String str) {
        System.out.println("[SERVER] - add " + str + " to " + allStrings);
        allStrings.add(str);
        return "Done";
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "findLastAmongAllStrings")
    public String findLastAmongAllStrings() {
        System.out.println("[SERVER] - Finding last String among " + allStrings);
        return allStrings.get(allStrings.size()-1);
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "addStudent")
    public String addStudent(@WebParam(name = "student") Student student) {
        System.out.println("[SERVER] - add " + student + " to " + allStudents);
        allStudents.add(student);
        return "Done";
    }


    /**
     * Web service operation
     */
    @WebMethod(operationName = "findStudentSurnameWithId")
    public String findStudentSurnameWithId(@WebParam(name = "surname") String id) {
        System.out.println("[SERVER] - Finding student surname with id " + id);
        String studentSurname = "Not Found";

        for (int i = 0; i < allStudents.size(); i++) {
            if (allStudents.get(i).getId().equals(id)) {
                studentSurname = allStudents.get(i).getSurname();
            }
        }
        return studentSurname;
    }
}
