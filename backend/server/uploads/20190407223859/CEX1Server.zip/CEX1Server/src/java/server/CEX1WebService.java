/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import java.util.ArrayList;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author Gab
 */
@WebService(serviceName = "CEX1WebService")
public class CEX1WebService 
{
    /*
    ArrayList of all Strings
    */
    ArrayList<String>    allStrings   =   new ArrayList<String>();
    /*
    ArrayList of all Strings
    */
    ArrayList<Student>   allStudents  =   new ArrayList<Student>();
    
    /**
     * Web service operation
     */
    @WebMethod(operationName = "testConnection")
    public String testConnection() 
    {
        System.out.println("[SERVER] - Testing Connection");
        return "OK";
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "findLargestDoubleBetween")
    public Double findLargestDoubleBetween(@WebParam(name = "a") Double a, @WebParam(name = "b") Double b) {
        System.out.println("[SERVER] - findLargestDoubleBetween");
        if(a > b)
            return a;
        else
            return b;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "findLargestDoubleBetweenWithException")
    public Double findLargestDoubleBetweenWithException(@WebParam(name = "a") Double a, @WebParam(name = "b") Double b) throws Exception {
        System.out.println("[SERVER] - findLargestDoubleBetweenWithException");
        
        if(a == null)
            throw new Exception();

        if(b == null)
            throw new Exception();

        if(a > b)
            return a;
        else
            return b;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "addString")
    public String addString(@WebParam(name = "str") String str) {
        System.out.println("[SERVER] - add " + str + " to " + allStrings);
        allStrings.add(str);
        return "Done";
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "findLongestAmongAllStrings")
    public String findLongestAmongAllStrings() {
        System.out.println("[SERVER] - Finding longest String among " + allStrings);
        String  longest    =   allStrings.get(0);
        for(int i = 0; i < allStrings.size(); i++)
            if(longest.length() < allStrings.get(i).length())
                longest = allStrings.get(i);
        
        return longest;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "addStudent")
    public String addStudent(@WebParam(name = "student") Student student) {
        System.out.println("[SERVER] - add " + student + " to " + allStudents);
        allStudents.add(student);
        return "Done";
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "findStudentNameWithId")
    public String findStudentNameWithId(@WebParam(name = "id")
            String id) {
        System.out.println("[SERVER] - Finding longest String among " + allStudents);
        String studentName = "Not Found";
        
        for(int i = 0; i < allStudents.size(); i++)
            if(allStudents.get(i).getId().equals(id))
                studentName = allStudents.get(i).getName();
 
        return studentName;
    }
}
