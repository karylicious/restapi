package src;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Carla-PC
 */
public class Start {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
            // System.setProperty("com.sun.xml.ws.transport.http.client.HttpTransportPipe.dump", "true");
           // System.setProperty("com.sun.xml.ws.transport.http.HttpAdapter.dump", "true");
           //System.setProperty("com.sun.xml.internal.ws.transport.http.client.HttpTransportPipe.dump", "true");
            //System.setProperty("com.sun.xml.internal.ws.transport.http.HttpAdapter.dump", "true");
        
        System.out.println(hello("Carla"));
        System.out.println(divide(3, 0));
    }

    private static String hello(java.lang.String name) {
        example.Calculator_Service service = new example.Calculator_Service();
        example.Calculator port = service.getCalculatorPort();
        return port.hello(name);
    }

    private static int divide(int arg0, int arg1) {
        example.Calculator_Service service = new example.Calculator_Service();
        example.Calculator port = service.getCalculatorPort();
        return port.divide(arg0, arg1);
    }
    
}
