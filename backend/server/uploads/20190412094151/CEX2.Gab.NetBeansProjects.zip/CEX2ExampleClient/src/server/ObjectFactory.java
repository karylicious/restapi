
package server;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the server package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _GetNameOfPersonResponse_QNAME = new QName("http://server/", "getNameOfPersonResponse");
    private final static QName _AddPersonToServerResponse_QNAME = new QName("http://server/", "addPersonToServerResponse");
    private final static QName _IsConnectedResponse_QNAME = new QName("http://server/", "isConnectedResponse");
    private final static QName _GetSurnameOfPerson_QNAME = new QName("http://server/", "getSurnameOfPerson");
    private final static QName _GetSurnameOfPersonResponse_QNAME = new QName("http://server/", "getSurnameOfPersonResponse");
    private final static QName _FindNameOfPersonOnServerWithSurnameResponse_QNAME = new QName("http://server/", "findNameOfPersonOnServerWithSurnameResponse");
    private final static QName _GetNameOfPerson_QNAME = new QName("http://server/", "getNameOfPerson");
    private final static QName _IsConnected_QNAME = new QName("http://server/", "isConnected");
    private final static QName _AddPersonToServer_QNAME = new QName("http://server/", "addPersonToServer");
    private final static QName _FindNameOfPersonOnServerWithSurname_QNAME = new QName("http://server/", "findNameOfPersonOnServerWithSurname");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: server
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link FindNameOfPersonOnServerWithSurname }
     * 
     */
    public FindNameOfPersonOnServerWithSurname createFindNameOfPersonOnServerWithSurname() {
        return new FindNameOfPersonOnServerWithSurname();
    }

    /**
     * Create an instance of {@link AddPersonToServer }
     * 
     */
    public AddPersonToServer createAddPersonToServer() {
        return new AddPersonToServer();
    }

    /**
     * Create an instance of {@link FindNameOfPersonOnServerWithSurnameResponse }
     * 
     */
    public FindNameOfPersonOnServerWithSurnameResponse createFindNameOfPersonOnServerWithSurnameResponse() {
        return new FindNameOfPersonOnServerWithSurnameResponse();
    }

    /**
     * Create an instance of {@link GetNameOfPerson }
     * 
     */
    public GetNameOfPerson createGetNameOfPerson() {
        return new GetNameOfPerson();
    }

    /**
     * Create an instance of {@link IsConnected }
     * 
     */
    public IsConnected createIsConnected() {
        return new IsConnected();
    }

    /**
     * Create an instance of {@link GetSurnameOfPerson }
     * 
     */
    public GetSurnameOfPerson createGetSurnameOfPerson() {
        return new GetSurnameOfPerson();
    }

    /**
     * Create an instance of {@link GetSurnameOfPersonResponse }
     * 
     */
    public GetSurnameOfPersonResponse createGetSurnameOfPersonResponse() {
        return new GetSurnameOfPersonResponse();
    }

    /**
     * Create an instance of {@link GetNameOfPersonResponse }
     * 
     */
    public GetNameOfPersonResponse createGetNameOfPersonResponse() {
        return new GetNameOfPersonResponse();
    }

    /**
     * Create an instance of {@link AddPersonToServerResponse }
     * 
     */
    public AddPersonToServerResponse createAddPersonToServerResponse() {
        return new AddPersonToServerResponse();
    }

    /**
     * Create an instance of {@link IsConnectedResponse }
     * 
     */
    public IsConnectedResponse createIsConnectedResponse() {
        return new IsConnectedResponse();
    }

    /**
     * Create an instance of {@link Person }
     * 
     */
    public Person createPerson() {
        return new Person();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetNameOfPersonResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://server/", name = "getNameOfPersonResponse")
    public JAXBElement<GetNameOfPersonResponse> createGetNameOfPersonResponse(GetNameOfPersonResponse value) {
        return new JAXBElement<GetNameOfPersonResponse>(_GetNameOfPersonResponse_QNAME, GetNameOfPersonResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddPersonToServerResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://server/", name = "addPersonToServerResponse")
    public JAXBElement<AddPersonToServerResponse> createAddPersonToServerResponse(AddPersonToServerResponse value) {
        return new JAXBElement<AddPersonToServerResponse>(_AddPersonToServerResponse_QNAME, AddPersonToServerResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IsConnectedResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://server/", name = "isConnectedResponse")
    public JAXBElement<IsConnectedResponse> createIsConnectedResponse(IsConnectedResponse value) {
        return new JAXBElement<IsConnectedResponse>(_IsConnectedResponse_QNAME, IsConnectedResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetSurnameOfPerson }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://server/", name = "getSurnameOfPerson")
    public JAXBElement<GetSurnameOfPerson> createGetSurnameOfPerson(GetSurnameOfPerson value) {
        return new JAXBElement<GetSurnameOfPerson>(_GetSurnameOfPerson_QNAME, GetSurnameOfPerson.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetSurnameOfPersonResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://server/", name = "getSurnameOfPersonResponse")
    public JAXBElement<GetSurnameOfPersonResponse> createGetSurnameOfPersonResponse(GetSurnameOfPersonResponse value) {
        return new JAXBElement<GetSurnameOfPersonResponse>(_GetSurnameOfPersonResponse_QNAME, GetSurnameOfPersonResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FindNameOfPersonOnServerWithSurnameResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://server/", name = "findNameOfPersonOnServerWithSurnameResponse")
    public JAXBElement<FindNameOfPersonOnServerWithSurnameResponse> createFindNameOfPersonOnServerWithSurnameResponse(FindNameOfPersonOnServerWithSurnameResponse value) {
        return new JAXBElement<FindNameOfPersonOnServerWithSurnameResponse>(_FindNameOfPersonOnServerWithSurnameResponse_QNAME, FindNameOfPersonOnServerWithSurnameResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetNameOfPerson }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://server/", name = "getNameOfPerson")
    public JAXBElement<GetNameOfPerson> createGetNameOfPerson(GetNameOfPerson value) {
        return new JAXBElement<GetNameOfPerson>(_GetNameOfPerson_QNAME, GetNameOfPerson.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IsConnected }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://server/", name = "isConnected")
    public JAXBElement<IsConnected> createIsConnected(IsConnected value) {
        return new JAXBElement<IsConnected>(_IsConnected_QNAME, IsConnected.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddPersonToServer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://server/", name = "addPersonToServer")
    public JAXBElement<AddPersonToServer> createAddPersonToServer(AddPersonToServer value) {
        return new JAXBElement<AddPersonToServer>(_AddPersonToServer_QNAME, AddPersonToServer.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FindNameOfPersonOnServerWithSurname }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://server/", name = "findNameOfPersonOnServerWithSurname")
    public JAXBElement<FindNameOfPersonOnServerWithSurname> createFindNameOfPersonOnServerWithSurname(FindNameOfPersonOnServerWithSurname value) {
        return new JAXBElement<FindNameOfPersonOnServerWithSurname>(_FindNameOfPersonOnServerWithSurname_QNAME, FindNameOfPersonOnServerWithSurname.class, null, value);
    }

}
