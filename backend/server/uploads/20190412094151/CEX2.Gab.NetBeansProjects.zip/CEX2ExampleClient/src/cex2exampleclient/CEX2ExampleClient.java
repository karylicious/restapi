/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cex2exampleclient;

import server.Person;

/**
 *
 * @author Gab
 */
public class CEX2ExampleClient {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        CEX2ExampleClient c = new CEX2ExampleClient();
        c.executeTest();
        // TODO code application logic here
    }

    private void executeTest() {
        if (isConnected()) {
            Person p1 = new Person();
            p1.setName("Gab");
            p1.setSurname("Pierantoni");
            
            if (getNameOfPerson(p1).equals("Gab")) {
                System.out.println("OK");
            } else {
                System.out.println("ERROR");
            }

            if (getSurnameOfPerson(p1).equals("Pierantoni")) {
                System.out.println("OK");
            } else {
                System.out.println("ERROR");
            }

            addPersonToServer(p1);
            System.out.println("Name of Pierantoni is " + findNameOfPersonOnServerWithSurname("Pierantoni"));
            
        } else {
            System.out.println("ERROR");
        }

    }

    private static Boolean isConnected() {
        server.CEX2ExampleWebServer_Service service = new server.CEX2ExampleWebServer_Service();
        server.CEX2ExampleWebServer port = service.getCEX2ExampleWebServerPort();
        return port.isConnected();
    }

    private static String getNameOfPerson(server.Person p) {
        server.CEX2ExampleWebServer_Service service = new server.CEX2ExampleWebServer_Service();
        server.CEX2ExampleWebServer port = service.getCEX2ExampleWebServerPort();
        return port.getNameOfPerson(p);
    }

    private static String getSurnameOfPerson(server.Person p) {
        server.CEX2ExampleWebServer_Service service = new server.CEX2ExampleWebServer_Service();
        server.CEX2ExampleWebServer port = service.getCEX2ExampleWebServerPort();
        return port.getSurnameOfPerson(p);
    }

    private static String addPersonToServer(server.Person p) {
        server.CEX2ExampleWebServer_Service service = new server.CEX2ExampleWebServer_Service();
        server.CEX2ExampleWebServer port = service.getCEX2ExampleWebServerPort();
        return port.addPersonToServer(p);
    }

    private static String findNameOfPersonOnServerWithSurname(java.lang.String name) {
        server.CEX2ExampleWebServer_Service service = new server.CEX2ExampleWebServer_Service();
        server.CEX2ExampleWebServer port = service.getCEX2ExampleWebServerPort();
        return port.findNameOfPersonOnServerWithSurname(name);
    }

}
