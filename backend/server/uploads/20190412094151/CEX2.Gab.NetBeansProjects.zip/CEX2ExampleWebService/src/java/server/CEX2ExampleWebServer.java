/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import java.util.ArrayList;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author Gab
 */
@WebService(serviceName = "CEX2ExampleWebServer")
public class CEX2ExampleWebServer {

    ArrayList<Person> people = new ArrayList<Person>();

    /**
     * Web service operation
     */
    @WebMethod(operationName = "isConnected")
    public Boolean isConnected() {
        System.out.println("[SERVER] - isConnected");
        return true;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "getNameOfPerson")
    public String getNameOfPerson(@WebParam(name = "p") Person p) {
        System.out.println("[SERVER] - getNameOfPerson");
        return p.getName();
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "getSurnameOfPerson")
    public String getSurnameOfPerson(@WebParam(name = "p") Person p) {
        System.out.println("[SERVER] - getSurnameOfPerson");
        return p.getSurname();
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "addPersonToServer")
    public String addPersonToServer(@WebParam(name = "p") Person p) {
        System.out.println("[SERVER] - Adding " + p + " to " + people);
        people.add(p);
        return null;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "findNameOfPersonOnServerWithSurname")
    public String findNameOfPersonWithSurname(@WebParam(name = "name") String surname) {
        for (int i = 0; i < people.size(); i++) 
        {
            System.out.println("checking " + people.get(i));
            System.out.println("comparing " + people.get(i).getSurname() + " with " + surname);
            
            if (people.get(i).getSurname().equals(surname)) {
                return people.get(i).getName();
            }
        }
        return null;
    }
}
