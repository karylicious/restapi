/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package example;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author Carla-PC
 */
@WebService(serviceName = "Calculator")
public class Calculator {

    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "hello")
    public String hello(@WebParam(name = "name") String txt) {
        return "Hello " + txt + " !";
    }
    
    
    @WebMethod(operationName = "sum")
    public int sum(int a, int b) {
        return a+b;
    } 

    @WebMethod(operationName = "diff")
    public int diff(int a, int b) {
        return a-b;
    } 

    @WebMethod(operationName = "multiply")
    public int multiply(int a, int b) {
        return a*b;
    }

    @WebMethod(operationName = "divide")
    public int divide(int a, int b) {
        return a/b;
    }
    
}
