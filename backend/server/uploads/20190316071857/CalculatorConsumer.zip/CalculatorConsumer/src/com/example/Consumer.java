package com.example;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Carla-PC
 */
public class Consumer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        int a = 13;
        int b = 4;
        int result = multiply(a, b);
        System.out.println("Result = " + result);
    }    
    
    private static int multiply(int a, int b) throws Exception{  
        CalculatorService calculatorService = new CalculatorService();
        Calculator calculator = calculatorService.getCalculatorPort();
        return calculator.multiply(a, b);
    }    
}