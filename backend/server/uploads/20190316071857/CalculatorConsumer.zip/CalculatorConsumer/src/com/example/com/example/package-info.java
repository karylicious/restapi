@javax.xml.bind.annotation.XmlSchema(namespace = "http://example.com/")
package com.example;
